@echo off
chcp 65001 >nul
title 원클릭 콘텐츠 스튜디오 (PC)
cd /d "%~dp0"
cls
echo ==================================================
echo    원클릭 콘텐츠 스튜디오 - PC 버전
echo ==================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [안내] 파이썬이 설치되어 있지 않습니다.
  echo.
  echo  1. 열리는 페이지에서 파이썬을 내려받아 설치하세요.
  echo  2. 설치 첫 화면의 "Add python.exe to PATH" 를 꼭 체크하세요.
  echo  3. 설치가 끝나면 이 파일을 다시 두 번 눌러 주세요.
  echo.
  start https://www.python.org/downloads/
  pause
  exit /b
)

python -c "import PIL, edge_tts, imageio_ffmpeg" >nul 2>nul
if errorlevel 1 (
  echo [설치] 처음 한 번만 필요한 파일을 내려받습니다. 1~3분 걸립니다...
  echo.
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo.
    echo [실패] 설치에 실패했습니다. 인터넷 연결을 확인한 뒤 다시 실행해 주세요.
    pause
    exit /b
  )
  echo.
  echo [완료] 준비가 끝났습니다.
)

python app.py
if errorlevel 1 (
  echo.
  echo 프로그램이 오류로 멈췄습니다. 위의 메시지를 복사해 두면 해결이 빠릅니다.
  pause
)
