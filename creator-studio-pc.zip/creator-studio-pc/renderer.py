# -*- coding: utf-8 -*-
"""
원클릭 콘텐츠 스튜디오 — PC 렌더러
9:16 (1080x1920) H.264 MP4 + 한국어 음성(edge-tts) + 안전영역 자막
Pillow 로 프레임을 직접 그리고 ffmpeg 로 인코딩합니다.
"""
from __future__ import annotations

import base64
import io
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import wave
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1080, 1920
FPS = 30
SAFE_BOTTOM = 420          # 쇼츠 하단 UI 안전영역
SUB_BOTTOM = 360           # 자막 박스 아래 여백
FONT_CANDIDATES = {
    "black": ["NanumGothic-ExtraBold.ttf", "NanumGothic-Bold.ttf"],
    "bold": ["NanumGothic-Bold.ttf", "NanumGothic-Regular.ttf"],
}
WINDOWS_FONTS = [
    r"C:\Windows\Fonts\malgunbd.ttf",
    r"C:\Windows\Fonts\malgun.ttf",
]


class RenderError(Exception):
    pass


# ---------------------------------------------------------------- ffmpeg / fonts
def find_ffmpeg(base: Path | None = None) -> str:
    env = os.environ.get("PC_FFMPEG")
    if env and Path(env).exists():
        return env
    local = (base or Path.cwd()) / "bin"
    for name in ("ffmpeg.exe", "ffmpeg"):
        p = local / name
        if p.exists():
            return str(p)
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:  # pip 로 설치한 imageio-ffmpeg 동봉 바이너리
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    raise RenderError(
        "ffmpeg 를 찾지 못했습니다. run_windows.bat 를 다시 실행하면 자동 설치됩니다. "
        "(수동: pip install imageio-ffmpeg)"
    )


def font_paths(base: Path) -> dict[str, str]:
    fonts: dict[str, str] = {}
    for weight, names in FONT_CANDIDATES.items():
        for n in names:
            p = base / "fonts" / n
            if p.exists():
                fonts[weight] = str(p)
                break
    for f in WINDOWS_FONTS:
        if Path(f).exists():
            fonts.setdefault("bold", f)
            fonts.setdefault("black", f)
            break
    if not fonts:
        # 리눅스/맥 흔한 경로
        for f in [
            "/usr/share/fonts/pickle-hwp/NotoSansCJKkr-Regular.otf",
            "/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf",
            "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        ]:
            if Path(f).exists():
                fonts["bold"] = f
                fonts["black"] = f
                break
    if not fonts:
        raise RenderError("한글 폰트를 찾지 못했습니다. fonts 폴더의 NanumGothic-Bold.ttf 를 확인하세요.")
    fonts.setdefault("black", fonts.get("bold"))
    fonts.setdefault("bold", fonts.get("black"))
    return fonts


# ---------------------------------------------------------------- 텍스트 도우미
def wrap_text(text: str, font: ImageFont.FreeTypeFont, max_w: int, max_lines: int) -> list[str]:
    lines, line = [], ""
    for ch in str(text):
        if ch == "\n":
            lines.append(line)
            line = ""
            continue
        test = line + ch
        if font.getlength(test) > max_w and line:
            lines.append(line)
            line = ch
            if len(lines) == max_lines:
                break
        else:
            line = test
    if line and len(lines) < max_lines:
        lines.append(line)
    if len(lines) == max_lines and len("".join(lines)) < len(str(text)):
        last = lines[-1]
        while len(last) > 1 and font.getlength(last + "…") > max_w:
            last = last[:-1]
        lines[-1] = last + "…"
    return lines


def wrap_words(text: str, font: ImageFont.FreeTypeFont, max_w: int, max_lines: int) -> list[str]:
    """띄어쓰기 우선 줄바꿈(한글 자막 가독성). 한 단어가 너무 길면 글자 단위로 자름."""
    s = str(text).strip()
    if not s:
        return []
    tokens = s.split(" ")
    lines: list[str] = []
    cur = ""
    truncated = False
    for w in tokens:
        cand = (cur + " " + w) if cur else w
        if font.getlength(cand) <= max_w:
            cur = cand
            continue
        if cur:
            lines.append(cur)
            cur = ""
            if len(lines) == max_lines:
                truncated = True
                break
        if font.getlength(w) <= max_w:
            cur = w
            continue
        for ch in w:                      # 너무 긴 단어는 글자 단위로
            if font.getlength(cur + ch) > max_w and cur:
                lines.append(cur)
                cur = ch
                if len(lines) == max_lines:
                    truncated = True
                    break
            else:
                cur += ch
        if truncated:
            break
    if cur and len(lines) < max_lines:
        lines.append(cur)
    elif cur:
        truncated = True
    if truncated and lines:
        last = lines[-1]
        while len(last) > 1 and font.getlength(last + "…") > max_w:
            last = last[:-1]
        lines[-1] = last + "…"
    return lines


def rounded(draw: ImageDraw.ImageDraw, box, radius: int, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def vertical_gradient(size, top_color, bottom_color) -> Image.Image:
    w, h = size
    grad = Image.new("RGBA", (1, h))
    d = ImageDraw.Draw(grad)
    for y in range(h):
        p = y / max(1, h - 1)
        c = tuple(int(top_color[i] + (bottom_color[i] - top_color[i]) * p) for i in range(4))
        d.point((0, y), c)
    return grad.resize((w, h), Image.BILINEAR)


# ---------------------------------------------------------------- 미디어
def load_image(src: str, work: Path, idx: int) -> Image.Image | None:
    if not src:
        return None
    try:
        if src.startswith("data:"):
            head, b64 = src.split(",", 1)
            raw = base64.b64decode(b64)
            return flatten(Image.open(io.BytesIO(raw)))
        if src.startswith("http://") or src.startswith("https://"):
            req = urllib.request.Request(src, headers={
                "User-Agent": "CreatorStudio/1.0 (https://github.com/kimjakyun/creator-studio; local video render)",
                "Accept": "image/*"})
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
            if len(raw) > 40 * 1024 * 1024:
                raise RenderError("이미지가 너무 큽니다(40MB 초과)")
            return flatten(Image.open(io.BytesIO(raw)))
    except Exception as e:
        print(f"[이미지] {idx} 불러오기 실패: {e}")
        return None
    return None


def flatten(im: Image.Image) -> Image.Image:
    """투명 PNG 를 어두운 배경에 올려 RGB 로 변환"""
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        bg = Image.new("RGB", im.size, (16, 20, 38))
        bg.paste(im, mask=im.split()[-1])
        return bg
    return im.convert("RGB")


def prepare_cover(img: Image.Image, zoom_max: float = 1.18) -> Image.Image:
    """Ken Burns 최대 확대까지 잘리지 않도록 넉넉히 키운 원본"""
    scale = max(W / img.width, H / img.height) * zoom_max
    return img.resize((max(W, int(img.width * scale)), max(H, int(img.height * scale))), Image.LANCZOS)


def crop_frame(pic: Image.Image, zoom: float, pan_dir: int, p: float) -> Image.Image:
    """확대·팬을 적용한 1080x1920 프레임"""
    cw = int(W * zoom * 1.0)
    ch = int(H * zoom * 1.0)
    cw = min(cw, pic.width)
    ch = min(ch, pic.height)
    # 팬: 확대된 여백 안에서 움직임
    max_x = max(0, pic.width - cw)
    max_y = max(0, pic.height - ch)
    px = 0.5 + pan_dir * (p - 0.5) * 0.16
    py = 0.5 - pan_dir * (p - 0.5) * 0.10
    x = int(max(0, min(1, px)) * max_x)
    y = int(max(0, min(1, py)) * max_y)
    return pic.crop((x, y, x + cw, y + ch)).resize((W, H), Image.BILINEAR)


# ---------------------------------------------------------------- 음성
def synth_tts(text: str, voice: str, out_mp3: Path, rate: str = "+5%") -> bool:
    """edge-tts 로 한국어 음성 생성. 실패하면 False (무음으로 진행)"""
    if not text.strip() or not voice:
        return False
    try:
        import asyncio
        import edge_tts
    except Exception as e:
        print(f"[음성] edge-tts 없음: {e}")
        return False

    async def run():
        comm = edge_tts.Communicate(text, voice, rate=rate)
        await comm.save(str(out_mp3))

    for attempt in range(2):
        try:
            asyncio.run(run())
            if out_mp3.exists() and out_mp3.stat().st_size > 1000:
                return True
        except Exception as e:
            print(f"[음성] 시도 {attempt+1} 실패: {e}")
            time.sleep(1.0)
    return False


def media_duration(ffmpeg: str, path: Path) -> float:
    try:
        p = subprocess.run([ffmpeg, "-i", str(path)], capture_output=True, text=True, timeout=30)
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", p.stderr)
        if m:
            return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    except Exception:
        pass
    return 0.0


def to_wav(ffmpeg: str, src: Path, dst: Path, seconds: float) -> bool:
    """mp3 → 44.1k 모노 wav, 부족한 길이는 무음으로 채움"""
    cmd = [ffmpeg, "-y", "-i", str(src), "-af", "apad", "-t", f"{seconds:.3f}",
           "-ar", "44100", "-ac", "1", "-f", "wav", str(dst)]
    try:
        subprocess.run(cmd, capture_output=True, timeout=120, check=True)
        return dst.exists()
    except Exception as e:
        print(f"[음성] wav 변환 실패: {e}")
        return False


def silence_wav(dst: Path, seconds: float) -> bool:
    w = wave.open(str(dst), "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(44100)
    w.writeframes(b"\x00\x00" * int(44100 * seconds))
    w.close()
    return True


def concat_wavs(parts: list[Path], dst: Path) -> bool:
    if not parts:
        return False
    with wave.open(str(parts[0]), "rb") as first:
        params = first.getparams()
    out = wave.open(str(dst), "wb")
    out.setparams(params)
    for p in parts:
        try:
            with wave.open(str(p), "rb") as r:
                if r.getnchannels() != params.nchannels or r.getframerate() != params.framerate:
                    continue
                out.writeframes(r.readframes(r.getnframes()))
        except Exception as e:
            print(f"[음성] 합치기 실패 {p.name}: {e}")
    out.close()
    return dst.exists()


# ---------------------------------------------------------------- 그리기
class Composer:
    def __init__(self, fonts: dict[str, str], hl: str = "#ffe066", watermark: str = ""):
        self.f_title = ImageFont.truetype(fonts["black"], 82)
        self.f_sub = ImageFont.truetype(fonts["bold"], 58)
        self.f_sub_small = ImageFont.truetype(fonts["bold"], 50)
        self.f_mark = ImageFont.truetype(fonts["bold"], 34)
        self.hl = hl
        self.watermark = watermark
        self.scrim_top = vertical_gradient((W, 760), (0, 0, 0, 185), (0, 0, 0, 0))
        self.scrim_bottom = vertical_gradient((W, 900), (0, 0, 0, 0), (0, 0, 0, 215))
        self.blank_bg = vertical_gradient((W, H), (27, 42, 94, 255), (8, 11, 22, 255))

    # --- 제목 (영상 내내 고정)
    def title_layer(self, title: str) -> Image.Image:
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if not title:
            return layer
        d = ImageDraw.Draw(layer)
        lines = wrap_words(title, self.f_title, W - 170, 2)
        lh = int(82 * 1.28)
        y0 = 190
        for i, line in enumerate(lines):
            tw = d.textlength(line, font=self.f_title)
            y = y0 + i * lh
            if i == len(lines) - 1:
                bb = d.textbbox((0, 0), line, font=self.f_title)
                bw = min(tw + 44, W - 90)
                top = y + bb[1] - 8
                bottom = y + bb[3] + 6
                rounded(d, (W / 2 - bw / 2, top, W / 2 + bw / 2, bottom), 12, self._rgba(self.hl, 150))
            # 그림자 (살짝 아래·번짐)
            shadow = Image.new("RGBA", (W, 200), (0, 0, 0, 0))
            sd = ImageDraw.Draw(shadow)
            sd.text((W / 2 - tw / 2, 60), line, font=self.f_title, fill=(0, 0, 0, 170))
            shadow = shadow.filter(ImageFilter.GaussianBlur(7))
            layer.alpha_composite(shadow, (0, y + 4 - 60))
            d.text((W / 2 - tw / 2, y), line, font=self.f_title, fill=(255, 255, 255, 255))
        return layer

    # --- 자막 박스 (컷마다 한 장)
    def subtitle_layer(self, text: str):
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if not text:
            return layer, None
        d = ImageDraw.Draw(layer)
        font = self.f_sub
        lines = wrap_words(text, font, W - 260, 2)
        if len("".join(lines)) > 40:
            font = self.f_sub_small
            lines = wrap_words(text, font, W - 270, 3)
        size = font.size
        lh = int(size * 1.34)
        box_h = lh * len(lines) + 46
        widths = [d.textlength(l, font=font) for l in lines]
        box_w = min(W - 120, int(max(widths)) + 96)
        cx = W / 2
        top = H - SUB_BOTTOM - box_h
        rounded(d, (cx - box_w / 2, top, cx + box_w / 2, top + box_h), 26, (8, 12, 26, 150))
        d.rounded_rectangle((cx - box_w / 2, top, cx + box_w / 2, top + box_h), radius=26,
                            outline=(255, 255, 255, 36), width=2)
        for i, line in enumerate(lines):
            tw = widths[i]
            ty = top + 23 + i * lh + (lh - size) / 2
            d.text((cx - tw / 2, ty + 2), line, font=font, fill=(0, 0, 0, 200))
            d.text((cx - tw / 2, ty), line, font=font, fill=(255, 255, 255, 255))
        return layer, (top + box_h - 12, box_w, cx)

    def footer(self, frame: Image.Image, progress: float):
        """상단 진행 바 + 워터마크. 알파가 살아 있도록 별도 층에 그려 합성한다."""
        bar = Image.new("RGBA", (W, 8), (0, 0, 0, 0))
        d = ImageDraw.Draw(bar)
        d.rectangle((0, 0, W, 8), fill=(255, 255, 255, 55))
        d.rectangle((0, 0, int(W * max(0.0, min(1.0, progress))), 8), fill=self._rgba(self.hl, 255))
        frame.alpha_composite(bar, (0, 0))
        if self.watermark:
            strip = Image.new("RGBA", (W, 200), (0, 0, 0, 0))
            sd = ImageDraw.Draw(strip)
            tw = sd.textlength(self.watermark, font=self.f_mark)
            sd.text((W / 2 - tw / 2, 82), self.watermark, font=self.f_mark, fill=(255, 255, 255, 200))
            frame.alpha_composite(strip, (0, H - 200))

    def progress_bar(self, frame: Image.Image, meta, fraction: float):
        top, box_w, cx = meta
        x0 = cx - (box_w - 36) / 2
        ov = Image.new("RGBA", (int(box_w), 12), (0, 0, 0, 0))
        d = ImageDraw.Draw(ov)
        d.rounded_rectangle((0, 0, box_w - 36, 5), radius=3, fill=(255, 255, 255, 70))
        d.rounded_rectangle((0, 0, (box_w - 36) * max(0.02, fraction), 5), radius=3,
                            fill=self._rgba(self.hl, 255))
        frame.alpha_composite(ov, (int(x0), int(top)))

    @staticmethod
    def _rgba(hex_color: str, alpha: int):
        h = hex_color.lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), alpha)


# ---------------------------------------------------------------- 렌더 본체
def render(project: dict, out_dir: Path, progress=None) -> Path:
    """
    project = {
      title, watermark, hl, voice,
      shots: [{text, seconds, image}]
    }
    """
    def tick(pct: int, msg: str = ""):
        if progress:
            progress(min(100, max(0, pct)), msg)

    shots = project.get("shots") or []
    if not shots:
        raise RenderError("장면이 없습니다. 대본을 먼저 만들어 주세요.")
    shots = shots[:12]

    job_dir = out_dir / f"job-{int(time.time())}-{os.getpid()}"
    job_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg = find_ffmpeg(BASE_DIR)
    fonts = font_paths(BASE_DIR)

    voice = (project.get("voice") or "").strip()
    tick(3, "음성과 사진을 준비하는 중")

    # 1) 사진
    images = []
    for i, s in enumerate(shots):
        img = load_image(s.get("image") or "", job_dir, i)
        images.append(prepare_cover(img) if img else None)

    # 2) 음성 → 컷 길이 확정
    audio_parts: list[Path] = []
    durations: list[float] = []
    use_voice = bool(voice)
    for i, s in enumerate(shots):
        text = str(s.get("text") or "")
        want = max(2.0, min(20.0, float(s.get("seconds") or 5)))
        dur = want
        wav = job_dir / f"a{i}.wav"
        ok = False
        if use_voice:
            mp3 = job_dir / f"a{i}.mp3"
            if synth_tts(text, voice, mp3):
                d = media_duration(ffmpeg, mp3)
                if d and d + 0.45 > want:
                    dur = min(25.0, d + 0.45)
                ok = to_wav(ffmpeg, mp3, wav, dur)
        if not ok:
            ok = silence_wav(wav, dur)
        audio_parts.append(wav)
        durations.append(dur)
        tick(5 + int(35 * (i + 1) / len(shots)), f"음성 {i+1}/{len(shots)}")

    audio_wav = job_dir / "audio.wav"
    audio_ok = use_voice and concat_wavs(audio_parts, audio_wav)

    total = sum(durations)
    composer = Composer(fonts, hl=project.get("hl") or "#ffe066", watermark=project.get("watermark") or "")
    title_layer = composer.title_layer(str(project.get("title") or ""))

    # 3) 프레임 → ffmpeg 파이프
    tick(42, "영상을 그리는 중")
    out_mp4 = out_dir / f"short-{time.strftime('%Y%m%d-%H%M%S')}.mp4"

    cmd = [ffmpeg, "-y", "-loglevel", "error",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0"]
    if audio_ok and use_voice:
        cmd += ["-i", str(audio_wav), "-c:a", "aac", "-b:a", "160k"]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-pix_fmt", "yuv420p", "-r", str(FPS), "-movflags", "+faststart"]
    if audio_ok and use_voice:
        cmd += ["-shortest"]
    cmd += [str(out_mp4)]

    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    frames_total = int(total * FPS)
    t_global = 0.0
    try:
        for i, s in enumerate(shots):
            seg_frames = max(1, int(round(durations[i] * FPS)))
            pic = images[i]
            sub_layer, meta = composer.subtitle_layer(str(s.get("text") or ""))
            if meta is None:
                meta = (H - 40, 40, W / 2)
            for f in range(seg_frames):
                p = f / seg_frames
                if pic is not None:
                    zoom = 1.06 + 0.10 * (p if i % 2 == 0 else 1 - p)
                    frame = crop_frame(pic, zoom, 1 if i % 2 == 0 else -1, p).convert("RGBA")
                else:
                    frame = composer.blank_bg.copy()
                frame.alpha_composite(composer.scrim_top, (0, 0))
                frame.alpha_composite(composer.scrim_bottom, (0, H - 900))
                frame.alpha_composite(title_layer, (0, 0))
                frame.alpha_composite(sub_layer, (0, 0))
                composer.progress_bar(frame, meta, p)
                composer.footer(frame, (t_global + f / FPS) / max(0.1, total))

                t = t_global + f / FPS
                fade = 0.35
                alpha = 0
                if t < fade:
                    alpha = 1 - t / fade
                elif t > total - fade:
                    alpha = min(1, (t - (total - fade)) / fade)
                rgb = frame.convert("RGB")
                if alpha > 0:
                    black = Image.new("RGB", (W, H), (0, 0, 0))
                    rgb = Image.blend(rgb, black, alpha)
                proc.stdin.write(rgb.tobytes())
                if f % 15 == 0:
                    done = int((t_global + f / FPS) * FPS)
                    tick(42 + int(48 * done / max(1, frames_total)), "영상을 그리는 중")
            t_global += durations[i]
        proc.stdin.close()
        err = proc.stderr.read().decode("utf-8", "ignore")
        if proc.wait() != 0:
            raise RenderError("ffmpeg 인코딩 실패: " + err[-500:])
    except BrokenPipeError:
        err = b""
        try:
            err = proc.stderr.read()
        except Exception:
            pass
        raise RenderError("ffmpeg 가 중간에 멈췄습니다: " + err.decode("utf-8", "ignore")[-400:])
    finally:
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass

    if not out_mp4.exists() or out_mp4.stat().st_size < 10000:
        raise RenderError("MP4 파일이 만들어지지 않았습니다. 콘솔 로그를 확인하세요.")

    tick(96, "마무리 정리 중")
    # 임시 파일 정리
    try:
        for p in job_dir.iterdir():
            p.unlink()
        job_dir.rmdir()
    except Exception:
        pass
    tick(100, "완료")
    return out_mp4


BASE_DIR = Path(__file__).resolve().parent

if __name__ == "__main__":
    # 간단 자체 점검: python renderer.py sample.json out.mp4
    src = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")) if len(sys.argv) > 1 else {
        "title": "테스트 영상입니다",
        "shots": [{"text": "첫 장면 자막", "seconds": 2}, {"text": "두 번째 장면 자막", "seconds": 2}],
    }
    out = render(src, BASE_DIR / "outputs", lambda p, m: print(f"{p}% {m}"))
    print("완료:", out)
