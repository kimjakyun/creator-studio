# -*- coding: utf-8 -*-
"""
원클릭 콘텐츠 스튜디오 — PC 실행 서버
실행: python app.py  (윈도우는 run_windows.bat 더블클릭)
브라우저가 자동으로 열립니다. 127.0.0.1 에서만 열리므로 외부에서 접속되지 않습니다.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import socket
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import renderer

# 윈도우 콘솔에서 한글이 깨져 멈추지 않도록 출력 인코딩을 고정
for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
MAX_BODY = 80 * 1024 * 1024   # 80MB (사진 포함 요청)


def set_job(job_id: str, **kw):
    with JOBS_LOCK:
        j = JOBS.setdefault(job_id, {"status": "running", "percent": 0, "message": "시작"})
        j.update(kw)
        j["updated"] = time.time()


def run_job(job_id: str, project: dict):
    def progress(pct, msg=""):
        set_job(job_id, percent=int(pct), message=msg or "렌더링 중")

    try:
        set_job(job_id, status="running", percent=1, message="준비 중")
        out = renderer.render(project, OUT, progress)
        set_job(job_id, status="done", percent=100, message="완료",
                url="/outputs/" + out.name, file=out.name)
    except Exception as e:
        traceback.print_exc()
        set_job(job_id, status="error", percent=0, message=str(e), error=str(e))


class Handler(SimpleHTTPRequestHandler):
    server_version = "CreatorStudio/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    # 조용한 로그 (필요한 줄만)
    def log_message(self, fmt, *args):
        if "/api/" in (self.path or ""):
            return
        sys.stdout.write("  · %s\n" % (fmt % args))

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]

        if path == "/api/health":
            try:
                ff = renderer.find_ffmpeg(BASE)
                ff_ok = bool(ff)
            except Exception:
                ff, ff_ok = "", False
            try:
                import edge_tts  # noqa: F401
                tts_ok = True
            except Exception:
                tts_ok = False
            try:
                fonts = renderer.font_paths(BASE)
                font_ok = bool(fonts.get("bold"))
            except Exception:
                font_ok = False
            return self._json({
                "ok": True, "app": "creator-studio", "version": "1.0.0",
                "ffmpeg": (Path(ff).name if ff else ""), "ffmpeg_ok": ff_ok,
                "edge_tts": tts_ok, "fonts": font_ok,
                "python": sys.version.split()[0],
                "outputs": str(OUT)
            })

        if path.startswith("/api/job/"):
            job_id = path.rsplit("/", 1)[-1]
            with JOBS_LOCK:
                j = JOBS.get(job_id)
            if not j:
                return self._json({"status": "error", "error": "없는 작업"}, 404)
            return self._json(j)

        if path.startswith("/outputs/"):
            name = path.split("/")[-1]
            safe = (OUT / name).resolve()
            if not str(safe).startswith(str(OUT.resolve())) or not safe.exists():
                self.send_error(404)
                return
            data = safe.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Content-Disposition", f'attachment; filename="{name}"')
            self.end_headers()
            self.wfile.write(data)
            return

        # static
        if path == "/" or path == "":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        path = self.path.split("?")[0]
        if path != "/api/render":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > MAX_BODY:
                return self._json({"error": "요청 크기가 올바르지 않습니다"}, 400)
            raw = self.rfile.read(length)
            project = json.loads(raw.decode("utf-8"))
            shots = project.get("shots") or []
            if not shots:
                return self._json({"error": "장면이 없습니다"}, 400)
            job_id = uuid.uuid4().hex[:12]
            set_job(job_id, status="running", percent=0, message="대기 중")
            t = threading.Thread(target=run_job, args=(job_id, project), daemon=True)
            t.start()
            return self._json({"job": job_id})
        except Exception as e:
            traceback.print_exc()
            return self._json({"error": str(e)}, 500)


def pick_port(start=8765, tries=20) -> int:
    for p in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    raise RuntimeError("사용 가능한 포트를 찾지 못했습니다")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=0)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    mimetypes.add_type("text/javascript", ".js")
    mimetypes.add_type("application/manifest+json", ".webmanifest")

    if not STATIC.exists():
        print("!! static 폴더가 없습니다. zip 압축을 풀 때 폴더째 풀어 주세요.")
        input("엔터를 누르면 종료합니다...")
        return

    try:
        ff = renderer.find_ffmpeg(BASE)
        print(f"  ffmpeg : {ff}")
    except Exception as e:
        print(f"  ffmpeg : 없음 ({e})")
    try:
        import edge_tts  # noqa
        print("  음성    : edge-tts 사용 가능")
    except Exception:
        print("  음성    : edge-tts 없음 → 무음 영상만 됩니다 (pip install edge-tts)")

    port = args.port or pick_port()
    url = f"http://127.0.0.1:{port}/"
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("\n" + "=" * 56)
    print("  ⚡ 원클릭 콘텐츠 스튜디오 (PC 모드)")
    print("  주소: " + url)
    print("  이 창을 닫으면 프로그램이 종료됩니다.")
    print("=" * 56 + "\n")

    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n종료합니다.")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
