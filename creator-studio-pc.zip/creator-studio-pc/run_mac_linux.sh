#!/bin/bash
# 맥 / 리눅스용 실행 스크립트
cd "$(dirname "$0")" || exit 1
echo "=================================================="
echo "   원클릭 콘텐츠 스튜디오 - PC 버전 (맥/리눅스)"
echo "=================================================="

if ! command -v python3 >/dev/null 2>&1; then
  echo "[안내] python3 가 없습니다. 먼저 설치해 주세요."
  exit 1
fi

if ! python3 -c "import PIL, edge_tts, imageio_ffmpeg" >/dev/null 2>&1; then
  echo "[설치] 필요한 파일을 내려받습니다..."
  python3 -m pip install --user -r requirements.txt || {
    echo "[실패] 설치 실패. 'python3 -m pip install --user -r requirements.txt' 를 직접 실행해 보세요."
    exit 1
  }
fi

python3 app.py
